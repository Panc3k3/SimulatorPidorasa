## Module Unsafe

#### `unsafeError`

``` purescript
unsafeError :: forall a. String -> a
```

Layman error handling


